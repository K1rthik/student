from django.urls import path
from . import views

urlpatterns = [
    path('mark/', views.mark, name='mark'),  # Ensure this is correctly mapped
    path('show/', views.show, name='show'),
]