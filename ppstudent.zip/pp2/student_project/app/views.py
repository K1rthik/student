# Create your views here.
from django.shortcuts import render, redirect
from app.forms import StudentsForm
from app.models import Marks

def mark(request):
    if request.method == "POST":
        print("POST method triggered")
        form = StudentsForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                print("Form saved successfully")
                return redirect('show')
            except Exception as e:
                print(f"Error saving form: {e}")
        else:
            print("Form is not valid")
            print("Form errors:", form.errors)  # Print form errors here
    else:
        form = StudentsForm()
    return render(request, 'index.html', {'form': form})

def show(request):
    students = Marks.objects.all()
    for student in students:
        student.total = int(student.mark1) + int(student.mark2) + int(student.mark3) + int(student.mark4) + int(student.mark5)
        student.average = student.total / 5
        student.save() 
    return render(request, "show.html", {'students': students})
