from django.urls import path
from . import views

urlpatterns = [
    path('marks1/',views.marks1),
    path('show/',views.show),
]