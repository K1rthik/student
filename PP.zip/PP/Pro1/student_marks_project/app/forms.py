from django import forms  
from app.models import Marks 
class StudentsForm(forms.ModelForm):  
    class Meta:  
        model = Marks  
        fields = "__all__"  
