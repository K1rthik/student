from django.shortcuts import render, redirect
from app.forms import StudentsForm
from app.models import Marks
# Create your views here.
def marks1(request):
    if request.method == "POST":
        form = StudentsForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('/show')
            except:
                pass
        else:
            print("not valid content")
    else:
        form = StudentsForm()
    return render(request, 'index.html', {'form': form})

def show(request):
    students = Marks.objects.all()
    for i in students:
        i.total=int(i.mark1)+int(i.mark2)+int(i.mark3)+int(i.mark4)+int(i.mark5)
        i.average=int(i.total/5)
    return render(request, "show.html", {'students': students})
