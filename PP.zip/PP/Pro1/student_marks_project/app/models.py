from django.db import models

class Marks(models.Model):
    name = models.CharField(max_length=50)
    id_number= models.IntegerField()
    mark1 = models.IntegerField()
    mark2 = models.IntegerField()
    mark3 = models.IntegerField()
    mark4 = models.IntegerField()
    mark5 = models.IntegerField()
    total = models.IntegerField(null=True)
    average = models.IntegerField(null=True)

    class Meta:  
        db_table = "marks"

